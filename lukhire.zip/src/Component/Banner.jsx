import React from "react";


const Banner = ({title})=>{
    return(
        <div className="category-lukhire-img">
        <header className="category-header">{title}</header>
    </div>
    )
}
export default Banner